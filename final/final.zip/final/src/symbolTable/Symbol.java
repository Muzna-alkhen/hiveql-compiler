package symbolTable;

public class Symbol
{
    public String name;
    public String type;
}
