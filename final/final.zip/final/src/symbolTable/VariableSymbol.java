package symbolTable;

public class VariableSymbol extends Symbol
{
//    public  String var_name;
//    public  String var_type;
}
